# import os
# import hou

# hipfolder = hou.getenv('HIP')

# dirs = hipfolder.split('/')
# new_PROJ = dirs[-5]
# new_SEQ  = dirs[-3]
# new_SHOT = dirs[-2]

# get_PROJ = hou.hscript("setenv -s PROJ")
# if 'undefined' in get_PROJ[0]:
# 	get_PROJ = None
# else:
# 	get_PROJ = get_PROJ[0].split('\t= ')[1].split('\n')[0]
    
# get_SEQ = hou.hscript("setenv -s SEQ")
# if 'undefined' in get_SEQ[0]:
# 	get_SEQ = None
# else:
# 	get_SEQ = get_SEQ[0].split('\t= ')[1].split('\n')[0]
#         get_SHOT = None

# get_SHOT = hou.hscript("setenv -s SHOT")
# if 'undefined' in get_SHOT[0]:
# 	get_SHOT = None
# else:
# 	get_SHOT = get_SHOT[0].split('\t= ')[1].split('\n')[0]

# print hou.hscript("setenv -s HIP")
# chk_env_exist = get_PROJ and get_SEQ and get_SHOT
# chk_env_compare = get_PROJ == new_PROJ and get_SEQ == new_SEQ and get_SHOT == new_SHOT

# if (chk_env_exist==None or chk_env_compare==False):
#     ui_chk_env = hou.ui.readMultiInput(message ="Current Local Variables is not Correct.\nDo you want fix it?\n\nCurrent:\nPROJ = {}\n SEQ = {}\nSHOT = {}".format(get_PROJ,get_SEQ,get_SHOT),
#                                    input_labels = ["PROJ"," SEQ","SHOT"],
#                                    title = "Multi TextField Dialog",
#                                    initial_contents =[new_PROJ,new_SEQ,new_SHOT],
#                                    buttons=["Accept","Cancel"])
    
#     if ( ui_chk_env[0] == 0 ):   
#         hou.hscript("setenv PROJ=\'{}\'".format(ui_chk_env[1][0]))
#         hou.hscript("setenv SEQ=\'{}\'".format(ui_chk_env[1][1]))
#         hou.hscript("setenv SHOT=\'{}\'".format(ui_chk_env[1][2]))